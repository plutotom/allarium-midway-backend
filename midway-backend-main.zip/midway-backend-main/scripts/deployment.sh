
#set the env variables

# git clone the project

# cd into the project dir

# execute the env
#export SECRET_KEY=to-be-set
#export SECRET_KEY=to-be-set

#TODO WIP

# start the daphne server
daphne -p 8080 diag8.asgi:application



